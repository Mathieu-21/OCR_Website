#include "stdio.h"
#include "math.h"
#include "SDL.h"
#include "SDL_image.h"
#include <err.h>
#include "load_image.h"


/*Allows to determine the value of a pixel at position x,y*/
Uint32 SDL_LirePixel(SDL_Surface* surface, int x, int y)
{
	int bpp = surface->format->BytesPerPixel;
 
  	Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;
 
  	switch(bpp)
  	{
             	case 1:
                  	return *p;
             	case 2:
                  	return *(Uint16 *)p;
             	case 3:
			if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
                     		return p[0] << 16 | p[1] << 8 | p[2];
                     	return p[0] | p[1] << 8 | p[2] << 16;
             	case 4:
 
 
                  	return *(Uint32 *)p;
             	default:
                  	return 0;
  	}	 
 
}
 
 
/*Writes a pixel at position x,y*/
void SDL_EcrirePixel(SDL_Surface* surface, int x, int y, Uint32 pixel)
{
	int bpp = surface->format->BytesPerPixel; 
    	Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp; 
 
 
    	switch(bpp) 
	{ 
		case 1: 
        		*p = pixel; 
        		break; 
 
    		case 2: 
	        	*(Uint16 *)p = pixel; 
        		break; 
 
    		case 3: 
        		if(SDL_BYTEORDER == SDL_BIG_ENDIAN) 
			{ 
				p[0] = (pixel >> 16) & 0xff; 
            			p[1] = (pixel >> 8) & 0xff; 
            			p[2] = pixel & 0xff; 
        		} 
			else 
			{ 
            			p[0] = pixel & 0xff; 
            			p[1] = (pixel >> 8) & 0xff; 
            			p[2] = (pixel >> 16) & 0xff; 
        		} 
       	 		break; 
 
    		case 4: 
			*(Uint32 *)p = pixel; 
        		break; 
    	}  
 
}

/*Performs a central rotation, automatically allocates memory*/
SDL_Surface* SDL_RotationCentralN(SDL_Surface* origine, float angle)
{
 	SDL_Surface* destination;
 	
	int i;
 	int j;
 
	Uint32 couleur;
 
	int mx, my, mxdest, mydest;
	int bx, by;
 
	float angle_radian;
	float tcos;
	float tsin;
 
	double largeurdest;
	double hauteurdest;
 
	/*Determines the value in radians of the angle*/
	angle_radian = -angle * M_PI / 180.0;
 
	/*To avoid lots of calls, we store the values*/
 	tcos = cos(angle_radian);
 	tsin = sin(angle_radian);
 
	/*Calculation of destination image size*/
 	largeurdest = ceil(origine->w * fabs(tcos) + origine->h * fabs(tsin)),
 	hauteurdest = ceil( origine->w * fabs(tsin) + origine->h * fabs(tcos)),
 
 
	/*Allocate memory to the destination space, attention, the surface is the same size*/
 
	destination = SDL_CreateRGBSurface(SDL_SWSURFACE, largeurdest, hauteurdest, origine->format->BitsPerPixel,
			origine->format->Rmask, origine->format->Gmask, origine->format->Bmask, origine->format->Amask);
 
 	/*Check that the memory has been allocated*/
 	if(destination==NULL)
  		return NULL;
 
 	/*Image center calculation*/
 	mxdest = destination->w/2.;
 	mydest = destination->h/2.;
 	mx = origine->w/2.;
	my = origine->h/2.;
 
 	for(j=0;j<destination->h;j++)
	{
  		for(i=0;i<destination->w;i++)
  		{
			/*We determine the pixel value that best corresponds for the position i,j of the destination surface*/
			/* We determine the best position on the original surface by applying an inverse rotation matrix */
 
   			bx = (ceil (tcos * (i-mxdest) + tsin * (j-mydest) + mx));
   			by = (ceil (-tsin * (i-mxdest) + tcos * (j-mydest) + my));
   
			/*We check that we do not leave the edges*/
   			if (bx>=0 && bx< origine->w && by>=0 && by< origine->h)
   			{
     				couleur = SDL_LirePixel(origine, bx, by);
     				SDL_EcrirePixel(destination, i, j, couleur);
   			}
 		}		
	}
 
	return destination;
}

int main(int argc,char **argv)
{
        if(argc != 3)
        {
                errx(1,"argc != 3");
        }
        SDL_Surface* surface = load_image(argv[1]);
        SDL_Surface* rotate = SDL_RotationCentralN(surface, atoi(argv[2]));
        SDL_SaveBMP(rotate,"imagerotate.bmp");
}
