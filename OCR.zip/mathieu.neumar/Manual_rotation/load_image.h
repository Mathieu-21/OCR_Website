#include <stdlib.h>
#include <stdio.h>
#include <math.h>

SDL_Surface* load_image(const char* path);

