SDL_Surface * load_image(const char * path) ;
void draw(SDL_Renderer * renderer, SDL_Texture * texture) ;
void event_loop(SDL_Renderer * renderer, SDL_Texture * t) ;
SDL_Surface * new_surface(SDL_Surface * surface, size_t x, size_t y, size_t x1,
  size_t y1) ;
int main(int argc, char ** argv) ;
