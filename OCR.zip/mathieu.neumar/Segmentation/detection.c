#include <SDL2/SDL_image.h>

#include <err.h>

#include <math.h>

#include <stdio.h>

#include <sys/stat.h>

#include "detection.h"

#include <SDL2/SDL.h>


SDL_Surface * load_image(const char * path) {
  // load the image , with the path of the image in parameter
  SDL_Surface * surf = IMG_Load(path);
  SDL_Surface * nf = SDL_ConvertSurfaceFormat(surf, SDL_PIXELFORMAT_RGB888, 0);
  SDL_FreeSurface(surf);
  return nf;
}

// Event loop that calls the relevant event handler.
//
// renderer: Renderer to draw on.
void draw(SDL_Renderer * renderer, SDL_Texture * texture) {

  if (SDL_RenderCopy(renderer, texture, NULL, NULL) != 0)
    errx(EXIT_FAILURE, "%s", SDL_GetError());
  SDL_RenderPresent(renderer);
}
void event_loop(SDL_Renderer * renderer, SDL_Texture * t) {
  SDL_Event event;
  while (1) {
    SDL_WaitEvent( & event);

    switch (event.type) {
      // If the "quit" button is pushed, ends the event loop.
    case SDL_QUIT:
      return;

      // If the window is resized, updates and redraws the diagonals.
    case SDL_WINDOWEVENT:
      if (event.window.event == SDL_WINDOWEVENT_RESIZED) {

        draw(renderer, t);
      }
      break;
    }
  }
}

void Accumulator_pixels_add(int diagonale, int y, int * acc, int x) {
  for (int angle = 0; angle < 180; ++angle) {
    int rayon
      = (sin(M_PI / 180 * angle)) * y + (cos(M_PI / 180 * angle)) * x;
    int condition = rayon < diagonale && rayon > 0;

    if (condition) {

      acc[angle + 360 * rayon] = acc[angle + 360 * rayon] + 1;
    }
  }
}
void Accumulator_Create(SDL_Surface * surface, int * acc, int diagonale, int w,
  int h, Uint32 * pixels) {
  for (int x = 0; x < w; x++) {

    for (int y = 0; y < h; y++) {

      SDL_PixelFormat * format = surface -> format;
      Uint8 r, g, b;

      SDL_GetRGB(pixels[y * w + x], format, & r, & g, & b);

      Uint8 rgb = r + g + b;
      if (rgb == 0) {
        Accumulator_pixels_add(diagonale, y, acc, x);
      }
    }
  }
}

void Accumulator_pixels_red(SDL_Surface * surface, int rayon, int angle) {
  SDL_PixelFormat * format = surface -> format;
  Uint32 red = SDL_MapRGB(format, 255, 0, 0);
  Uint32 * pixels = surface -> pixels;
  for (int x = 0; x < surface -> w; ++x) {
    for (int y = 0; y < surface -> h; ++y) {
      int rayon2 = ((sin(M_PI / 180 * angle)) * y +
        (cos(M_PI / 180 * angle)) * x);
      if (rayon2 == rayon) {
        int w = surface -> w;
        pixels[y * w + x] = red;
      }
    }
  }
}
void Accumulator_Browse(SDL_Surface * surface, int diagonale,
  int * acc) 
{

  for (int angle = 0; angle < 180; ++angle) {
    for (int rayon = 0; rayon < diagonale; ++rayon) {
      if (acc[angle + 360 * rayon] > surface -> h / 3 + 150) {
        // create red pixels where lines are
        Accumulator_pixels_red(surface, rayon,
          angle);
      }
    }
  }
}

void Accumulator_pixels_blue(SDL_Surface * surface, int rayon, int angle) {
  SDL_PixelFormat * format = surface -> format;
  Uint32 blue = SDL_MapRGB(format, 0, 255, 0);
  Uint32 * pixels = surface -> pixels;
  for (int x = 0; x < surface -> w; ++x) {
    for (int y = 0; y < surface -> h; ++y) {
      int rayon2 = ((sin(M_PI / 180 * angle)) * y +
        (cos(M_PI / 180 * angle)) * x);
      if (rayon2 == rayon) {
        int w = surface -> w;
        pixels[y * w + x] = blue;
      }
    }
  }
}

void Find_line(SDL_Surface * surface, int * acc, int diagonale, int width_r[],
  int width_angle[], int height_r[], int height_angle[]) {
  // horizontal
  int y = 50;
  int i = 0;
  for (int x = 0; x < surface -> w && i != 10; x++) {
    int ii = 0;
    for (int angle = 0; angle < 180 && ii == 0; ++angle) {
      int rayon
        = (sin(M_PI / 180 * angle)) * y + (cos(M_PI / 180 * angle)) * x;
      int condition = rayon < diagonale && rayon > 0;
      if (condition && acc[angle + 360 * rayon] > surface -> h / 3 + 50) {
        ++ii;

        width_angle[i] = angle;
        width_r[i] = rayon;
        ++i;
        x += 100;
      }
    }
  }
  // vertical
  int x = 50;
  i = 0;
  for (int y = 15; y < surface -> h && i != 11; y++) {
    int ii = 0;
    for (int angle = 0; angle < 180 && ii == 0; ++angle) {
      int rayon
        = (sin(M_PI / 180 * angle)) * y + (cos(M_PI / 180 * angle)) * x;
      int condition = rayon < diagonale && rayon > 0;
      if (condition && acc[angle + 360 * rayon] > surface -> h / 3 + 50) {
        ++ii;
        height_angle[i] = angle;
        height_r[i] = rayon;
        ++i;
        y += 100;
      }
    }
  }
}
void Find_inter(int height_r[],
  int height_angle[], int width_r[], int width_angle[],
  size_t inter[][2]) {

  for (int i = 0; i < 10; i++) {
    for (int k = 0; k < 10; k++) {

      size_t wr = width_r[i];
      size_t hr = height_r[k];
      float ch = cos(height_angle[k] * M_PI / 180);
      float sh = sin(height_angle[k] * M_PI / 180);
      float sw = sin(width_angle[i] * M_PI / 180);
      float cw = cos(width_angle[i] * M_PI / 180);

      size_t x = (sw * hr - sh * wr) / (sw * ch - sh * cw);

      size_t y = (wr - x * cw) / sw;

      inter[i * 10 + k][0] = x;
      inter[i * 10 + k][1] = y;
    }
  }
}

void colored(SDL_Surface * surface, int x, int y) {
  SDL_PixelFormat * format = surface -> format;
  Uint32 blue = SDL_MapRGB(format, 250, 37, 203);
  Uint32 * pixels = surface -> pixels;
  for (int i = -8; i < 8; i++) {
    for (int j = -8; j < 8; j++) {
      pixels[(y + i) * surface -> w + (x + j)] = blue;
    }
  }

}
SDL_Surface * new_surface(SDL_Surface * surface, size_t x, size_t y, size_t x1,
  size_t y1) {
  SDL_Surface * new = SDL_CreateRGBSurface(0, x, y, 32, 0, 0, 0, 0);
  Uint32 * pixels = new -> pixels;
  Uint32 * pix = surface -> pixels;
  for (size_t i = 0; i < x; i++) {
    for (size_t k = 0; k < y; k++) {
      pixels[k * x + i] = pix[(y1 + k) * surface -> w + (x1 + i)];
    }
  }
  return new;
}

SDL_Surface * nearest_neighbor(SDL_Surface * image) {
  // Create a new surface with the desired dimensions (28x28 in this case)
  int w = 28;
  int h = 28;
  SDL_Surface * new_surface = 
  SDL_CreateRGBSurface(0, w, h, image -> format -> BitsPerPixel,
   image -> format -> Rmask, image -> format -> Gmask,
    image -> format -> Bmask, image -> format -> Amask);
  Uint32 * pixels = new_surface -> pixels;
  Uint32 * pixels0 = image -> pixels;
  // Get the dimensions of the original image
  int w_original = image -> w;
  int h_original = image -> h;
  // Calculate the scaling factor for the x and y dimensions
  float x_scale = (float) w / (float) w_original;
  float y_scale = (float) h / (float) h_original;

  // For each pixel in the new image
  for (int x = 0; x < w; x++) {
    for (int y = 0; y < h; y++) {
      // Calculate the coordinates of the pixel in the original image
      int x_original = (int)((float) x / x_scale);
      int y_original = (int)((float) y / y_scale);

      // Get the value of the nearest pixel in the original image
      Uint32 pixel = pixels0[y_original * w_original + x_original];

      // Set the value of the new pixel
      pixels[y * w + x] = pixel;
    }
  }

  return new_surface;
}
void Cut_case(SDL_Surface * surface, size_t inter[][2], char ** argv) {        
  char dn[45];
  int j = 0;
  sprintf(dn, "case/list_%s", argv[1]);
  mkdir(dn, 0700);
  for (size_t i = 0; i <= 80; i += 10) {
    for (size_t k = 0; k < 9; k++) {

      size_t x = inter[i + k + 11][0] - inter[i + k][0];
      size_t y = inter[i + k + 11][1] - inter[i + k][1];
      char name[70];
      sprintf(name, "./%s/%i", dn, j);
      SDL_Surface * new = 
      new_surface(surface, 88, 88,
       inter[i + k][0] + x / 2 - 40, inter[i + k][1] + y / 2 - 40);
      SDL_Surface * new2 = nearest_neighbor(new);
      SDL_SaveBMP(new2, name);
      j++;
    }
  }
}

void only_grille(SDL_Surface * surface, size_t inter[][2], char ** argv) {
  char name[45];
  sprintf(name, "./gate/%s", argv[1]);
  SDL_Surface * new = new_surface(surface, inter[99][0] - inter[0][0],
   inter[99][1] - inter[0][1], inter[0][0], inter[0][1]);
  SDL_SaveBMP(new, name);
}

int main(int argc, char ** argv) {

  // Checks the number of arguments.
  if (argc != 2) errx(EXIT_FAILURE, "Usage: image-file");
  SDL_Surface * surface = load_image(argv[1]);

  if (surface == NULL) {
    errx(EXIT_FAILURE, "%s", SDL_GetError());
  }

  // Get size of image
  int h = surface -> h;
  int w = surface -> w;
  int diagonale = (int)(sqrt((double)(w * w + h * h)));
  // get pixels
  Uint32 * pixels = surface -> pixels;
  // accumulator
  int * acc = calloc(360 * diagonale, sizeof(int));
  Accumulator_Create(surface, acc, diagonale, w, h, pixels);

  // Accumulator_Browse(surface,diagonale,acc);
  int height_angle[10];
  int width_angle[10];
  int height_r[10];
  int width_r[10];
  size_t inter[100][2];
  Find_line(surface, acc, diagonale, width_r, width_angle, height_r,
    height_angle);
  Find_inter(width_r, width_angle, height_r,
    height_angle, inter);

  Cut_case(surface, inter, argv);

  //only_grille(surface, inter, argv);
  SDL_Window * window = SDL_CreateWindow(
    "final", 0, 0, 600, 400, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);

  if (window == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());
  SDL_SetWindowSize(window, w, h);
  SDL_Renderer * renderer = 
  SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

  if (renderer == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());

  SDL_Texture * texture = SDL_CreateTextureFromSurface(renderer, surface);
  if (texture == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());

  SDL_FreeSurface(surface);
  //event_loop(renderer, texture);
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);
  SDL_DestroyTexture(texture);
  SDL_Quit();

  //
  // - Initialize the SDL.
  // - Create a window.
  // - Create a renderer.
  // - Create a surface from the colored image.
  // - Resize the window according to the size of the image.
  // - Create a texture from the colored surface.
  // - Convert the surface into grayscale.
  // - Create a new texture from the grayscale surface.
  // - Free the surface.
  // - Dispatch the events.
  // - Destroy the objects.

  return EXIT_SUCCESS;
}