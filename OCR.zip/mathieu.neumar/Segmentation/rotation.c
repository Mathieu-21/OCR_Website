#include <SDL2/SDL_image.h>

#include <err.h>

#include <math.h>

#include <stdio.h>

#include <sys/stat.h>                                                          

#include "rotation.h"

#include <SDL2/SDL.h>

SDL_Surface * load_image(const char * path) {
  // load the image , with the path of the image in parameter
  SDL_Surface * surf = IMG_Load(path);
  SDL_Surface * nf = SDL_ConvertSurfaceFormat(surf, SDL_PIXELFORMAT_RGB888, 0);
  SDL_FreeSurface(surf);
  return nf;
}

// Event loop that calls the relevant event handler.
//
// renderer: Renderer to draw on.
void draw(SDL_Renderer * renderer, SDL_Texture * texture) {

  if (SDL_RenderCopy(renderer, texture, NULL, NULL) != 0)
    errx(EXIT_FAILURE, "%s", SDL_GetError());
  SDL_RenderPresent(renderer);
}
void event_loop(SDL_Renderer * renderer, SDL_Texture * t) {
  SDL_Event event;
  while (1) {
    SDL_WaitEvent( & event);

    switch (event.type) {
      // If the "quit" button is pushed, ends the event loop.
    case SDL_QUIT:
      return;

      // If the window is resized, updates and redraws the diagonals.
    case SDL_WINDOWEVENT:
      if (event.window.event == SDL_WINDOWEVENT_RESIZED) {

        draw(renderer, t);
      }
      break;
    }
  }
}
SDL_Surface * new_surface(SDL_Surface * surface, size_t x, size_t y, size_t x1,
  size_t y1) {
  SDL_Surface * new = SDL_CreateRGBSurface(0, x, y, 32, 0, 0, 0, 0);
  Uint32 * pixels = new -> pixels;
  Uint32 * pix = surface -> pixels;
  for (size_t i = 0; i < x; i++) {
    for (size_t k = 0; k < y; k++) {
      pixels[k * x + i] = pix[(y1 + k) * surface -> w + (x1 + i)];
    }
  }
  return new;
}
void only_grille(SDL_Surface * surface, size_t Cood[4][2], char ** argv) {
  char name[45];
  sprintf(name, "./gate/%s_resized", argv[1]);
  SDL_Surface * new = new_surface(surface, Cood[1][0] - Cood[0][0], Cood[1][1] 
      - Cood[0][1], Cood[0][0], Cood[0][1]);
  SDL_SaveBMP(new, name);
}
int main(int argc, char ** argv) {

  // Checks the number of arguments.
  if (argc != 2) errx(EXIT_FAILURE, "Usage: image-file");
  SDL_Surface * surface = load_image(argv[1]);

  if (surface == NULL) {
    errx(EXIT_FAILURE, "%s", SDL_GetError());
  }
  SDL_Window * window = SDL_CreateWindow("Ma fenêtre SDL",
   SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480,
    SDL_WINDOW_SHOWN);
  SDL_Renderer * renderer = SDL_CreateRenderer(window, -1,
   SDL_RENDERER_ACCELERATED);
  SDL_Texture * texture = SDL_CreateTextureFromSurface(renderer, surface);
  size_t corner[4][2];
  Uint32 * pixels = surface -> pixels;
  SDL_PixelFormat * format = surface -> format;
  Uint8 r, g, b;
  int stop = 0;
  for (int y = 0; y < surface -> h; y++) {
    for (int x = 0; x < surface -> w; x++) {
      SDL_GetRGB(pixels[y * surface -> w + x], format, & r, & g, & b);
      Uint8 rgb = r + g + b;
      if (rgb == 0) {
        stop = 1;

        corner[0][0] = x;
        corner[0][1] = y;
        break;
      }
    }
    if (stop == 1) {
      break;
    }
  }
  stop = 0;
  for (int x = 0; x < surface -> w; x++) {
    for (int y = 0; y < surface -> h; y++) {
      SDL_GetRGB(pixels[y * surface -> w + x], format, & r, & g, & b);
      Uint8 rgb = r + g + b;
      if (rgb == 0) {
        stop = 1;

        corner[1][0] = x;
        corner[1][1] = y;
        break;
      }
    }
    if (stop == 1) {
      break;
    }
  }
  stop = 0;
  for (int x = 1; x < surface -> w; x++) {
    for (int y = 0; y < surface -> h; y++) {
      SDL_GetRGB(pixels[y * surface -> w + surface -> w - x], format, & r,
       & g, & b);
      Uint8 rgb = r + g + b;
      if (rgb == 0) {
        stop = 1;

        corner[2][0] = surface -> w - x;
        corner[2][1] = y;
        break;
      }
    }
    if (stop == 1) {
      break;
    }
  }
  stop = 0;
  for (int y = 1; y < surface -> h; y++) {

    for (int x = 0; x < surface -> w; x++) {
      SDL_GetRGB(pixels[(surface -> h - y) * surface -> w + x], format, & r,   
       & g, & b);
      Uint8 rgb = r + g + b;
                                                                               
      if (rgb == 0) {
        stop = 1;

        corner[3][0] = x;
        corner[3][1] = surface -> h - y;
        break;
      }
    }
    if (stop == 1) {
      break;
    }
  }
 
 
  int x2 = 0, y2 = 0;
  int x1 = surface -> w - 1, y1 = 0;
  int x3 = surface -> w - 1, y3 = surface -> h - 1;
  int x4 = 0, y4 = surface -> h - 1;

 
  int x1p = corner[0][0], y1p = corner[0][1];
  int x2p = corner[1][0], y2p = corner[1][1];
  int x3p = corner[2][0], y3p = corner[2][1];
  int x4p = corner[3][0], y4p = corner[3][1];

 
  double angle1 = atan2(y2 - y1, x2 - x1) - atan2(y2p - y1p, x2p - x1p);
  double angle2 = atan2(y3 - y2, x3 - x2) - atan2(y3p - y2p, x3p - x2p);
  double angle3 = atan2(y4 - y3, x4 - x3) - atan2(y4p - y3p, x4p - x3p);
  double angle4 = atan2(y1 - y4, x1 - x4) - atan2(y1p - y4p, x1p - x4p);

  
  double angle = (angle1 + angle2 + angle3 + angle4) / 4.0;


  int width = surface -> w * cos(angle) + surface -> h * sin(angle);
  int height = surface -> w * sin(angle) + surface -> h * cos(angle);

  SDL_Surface * new_surface = SDL_CreateRGBSurface(0, width, height, 32, 0, 0,
   0, 0);
  Uint32 * new_pixels = new_surface -> pixels;
 
  SDL_Color green = {
    0,
    255,
    0
  };

 
  SDL_Rect rect = {
    0,
    0,
    new_surface -> w,
    new_surface -> h
  };


  SDL_FillRect(new_surface, & rect, SDL_MapRGB(new_surface -> format, green.r,
   green.g, green.b));
  for (int i = 0; i < surface -> w; i++) {
    for (int j = 0; j < surface -> h; j++) {
     
      int x = i * cos(angle) - j * sin(angle) + width / 2.5;
      int y = i * sin(angle) + j * cos(angle);

      
      if (x >= 0 && x < new_surface -> w && y >= 0 && y < new_surface -> h) {
        SDL_GetRGB(pixels[j * surface -> w + i], format, & r, & g, & b);
        if (r + g + b > 382.5)
          new_pixels[y * new_surface -> w + x] = 
            SDL_MapRGB(new_surface -> format, 255, 255, 255);
        else
          new_pixels[y * new_surface -> w + x] = 
          SDL_MapRGB(new_surface -> format, 0, 0, 0);

      }

    }
  }
  for (size_t x = 0; x < new_surface -> w; x++) {
    for (size_t y = 0; y < new_surface -> h; y++) {
      if (new_pixels[y * new_surface -> w + x] == 
      SDL_MapRGB(new_surface -> format, green.r, green.g, green.b)) {
        int nb = 0;
        int res_r = 0;
        int res_g = 0;
        int res_b = 0;
        if (x > 0 && new_pixels[y * new_surface -> w + x - 1] != 
        SDL_MapRGB(new_surface -> format, green.r, green.g, green.b)) {
          nb++;
          SDL_GetRGB(new_pixels[y * new_surface -> w + x - 1], 
          format, & r, & g, & b);
          res_r += r;
          res_g += g;
          res_b += b;
        }
        if (x < new_surface -> w - 1 && 
        new_pixels[y * new_surface -> w + x + 1] != 
        SDL_MapRGB(new_surface -> format, green.r, green.g, green.b)) {
          nb++;
          SDL_GetRGB(new_pixels[y * new_surface -> w + x + 1], 
          format, & r, & g, & b);
          res_r += r;
          res_g += g;
          res_b += b;
        }
        if (y > 0 && new_pixels[(y - 1) * new_surface -> w + x]
         != SDL_MapRGB(new_surface -> format, green.r, green.g, green.b)) {
          nb++;
          SDL_GetRGB(new_pixels[(y - 1) * new_surface -> w + x],
           format, & r, & g, & b);
          res_r += r;
          res_g += g;
          res_b += b;
        }
        if (y < new_surface -> h - 1 &&
         new_pixels[(y + 1) * new_surface -> w + x] != 
         SDL_MapRGB(new_surface -> format, green.r, green.g, green.b)) {
          nb++;
          SDL_GetRGB(new_pixels[(y + 1) * new_surface -> w + x],
           format, & r, & g, & b);
          res_r += r;
          res_g += g;
          res_b += b;
        }
        if (nb == 0)
          new_pixels[y * new_surface -> w + x] = 
          SDL_MapRGB(new_surface -> format, 255, 255, 255);
        else {

          if ((int)((res_r + res_g + res_b) / nb) < 382.5)
            res_r = res_g = res_b = 0;
          else
            res_r = res_g = res_b = 255;

          new_pixels[y * new_surface -> w + x] = 
          SDL_MapRGB(new_surface -> format, res_r, res_g, res_b);
        }
      }
    }
  }

  size_t cood[2][2];
  cood[0][0] = x2p * cos(angle) - y2p * sin(angle) + width / 2.5;
  cood[0][1] = x2p * sin(angle) + y2p * cos(angle);
  cood[1][0] = x3p * cos(angle) - y3p * sin(angle) + width / 2.5;
  cood[1][1] = x3p * sin(angle) + y3p * cos(angle);
  only_grille(new_surface, cood, argv);
  SDL_RenderPresent(renderer);
  SDL_FreeSurface(surface);
  //event_loop(renderer, texture);
  SDL_Quit();

  //
  // - Initialize the SDL.
  // - Create a window.
  // - Create a renderer.
  // - Create a surface from the colored image.
  // - Resize the window according to the size of the image.
  // - Create a texture from the colored surface.
  // - Convert the surface into grayscale.
  // - Create a new texture from the grayscale surface.
  // - Free the surface.
  // - Dispatch the events.
  // - Destroy the objects.

  return EXIT_SUCCESS;
}