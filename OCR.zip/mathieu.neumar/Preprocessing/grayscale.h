#ifndef PREPROCESSING_H
#define PREPROCESSING_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>


Uint32 getpixel(SDL_Surface *surface, int x, int y);
void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel);
SDL_Surface *grayscale(SDL_Surface *image);
SDL_Surface *noise_removal(SDL_Surface *surface);
void save(SDL_Surface *image, char *path);

#endif
