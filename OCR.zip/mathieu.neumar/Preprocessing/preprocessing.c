#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include "grayscale.h"
#include <stddef.h>
#include <math.h>


Uint32 getpixel(SDL_Surface *surface, int x, int y) {
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch (bpp) {
    case 1:
        return *p;

    case 2:
        return *(Uint16 *)p;

    case 3:
        if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;

    case 4:
        return *(Uint32 *)p;

    default:
        return 0;
    }
}

void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel) {
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch (bpp) {
    case 1:
        *p = pixel;
        break;

    case 2:
        *(Uint16 *)p = pixel;
        break;

    case 3:
        if (SDL_BYTEORDER == SDL_BIG_ENDIAN) {
            p[0] = (pixel >> 16) & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = pixel & 0xff;
        } else {
            p[0] = pixel & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = (pixel >> 16) & 0xff;
        }
        break;

    case 4:
        *(Uint32 *)p = pixel;
        break;
    }
}

// Convert an image to grayscale
SDL_Surface *grayscale(SDL_Surface *image)
{
        for (int i = 0; i < image->w; i++)
    {
        for (int j = 0; j < image->h; j++)
        {
            Uint8 r, g, b;
            Uint32 pixel = getpixel(image, i, j);
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            Uint8 gray = r*0.2126 + g*0.7152 + b*0.0722;
            pixel = SDL_MapRGB(image->format, gray, gray, gray);
            putpixel(image, i, j, pixel);
        }
    }
    return image;
}


// Part of the noise cancellation filter
Uint32 median_pixel(SDL_Surface *image, int x, int y)
{
        int iArr = 0;
        Uint32 grayscaleArr[9];
        for (int i = -1; i < 2; i++)
        {
                for (int j = -1; j < 2; j++)
                {
                        grayscaleArr[iArr] = getpixel(image, x+i, y+j);
                        iArr++;
                }
        }

        for (int i = 0; i < 8; i++)
        {
                Uint32 min = i;
                for (int j = i+1; j < 9; j++) 
                    if (grayscaleArr[j] < grayscaleArr[min]) min = j;
                Uint32 tmp = grayscaleArr[i];
                grayscaleArr[i] = grayscaleArr[min];
                grayscaleArr[min] = tmp;
        }

        return grayscaleArr[4];
}

SDL_Surface* noise_canceled(SDL_Surface *image)
{
	int w;
	int h;
	w = image -> w;
	h = image -> h;
	for (int i = 1; i < w-1; i++)
	{
		for (int j = 1; j < h-1; j++) 
            putpixel(image, i, j, median_pixel(image, i, j));
	}
	return image;
}

int MAX(int a, int b)
{
  if (a > b) {
    return a;
  } else {
    return b;
  }
}

int MIN(int a, int b)
{
  if (a < b) {
    return a;
  } else {
    return b;
  }
}

// Part of the gaussian filter
SDL_Surface *gaussian_filter(SDL_Surface *image)
{
    int w;
    int h;
    w = image -> w;
    h = image -> h;
    int kernel[3][3] = {{1, 2, 1}, {2, 4, 2}, {1, 2, 1}};
    int kernel_sum = 16;
    for (int i = 1; i < w-1; i++)
    {
        for (int j = 1; j < h-1; j++)
        {
            int r = 0;
            int g = 0;
            int b = 0;
            for (int k = -1; k < 2; k++)
            {
                for (int l = -1; l < 2; l++)
                {
                    Uint8 r1, g1, b1;
                    Uint32 pixel = getpixel(image, i+k, j+l);
                    SDL_GetRGB(pixel, image->format, &r1, &g1, &b1);
                    r += r1 * kernel[k+1][l+1];
                    g += g1 * kernel[k+1][l+1];
                    b += b1 * kernel[k+1][l+1];
                }
            }
            r /= kernel_sum;
            g /= kernel_sum;
            b /= kernel_sum;
            Uint32 pixel = SDL_MapRGB(image->format, r, g, b);
            putpixel(image, i, j, pixel);
        }
    }
    return image;
}

// Image Saturation
SDL_Surface *saturation(SDL_Surface *image){
    int w;
    int h;
    w = image -> w;
    h = image -> h;
    for (int i = 0; i < w; i++)
    {
        for (int j = 0; j < h; j++)
        {
            Uint8 r, g, b;
            Uint32 pixel = getpixel(image, i, j);
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            int max = MAX(r, MAX(g, b));
            int min = MIN(r, MIN(g, b));
            int delta = max - min;
            if (delta == 0) continue;
            int s = (delta * 255) / max;
            int v = max;
            int h;
            if (r == max) h = (g - b) / delta;
            else if (g == max) h = 2 + (b - r) / delta;
            else h = 4 + (r - g) / delta;
            h *= 60;
            if (h < 0) h += 360;
            if (s < 50) continue;
            if (h < 20 || h > 160) continue;
            if (v < 100) continue;
            Uint32 pixel2 = SDL_MapRGB(image->format, 255, 255, 255);
            putpixel(image, i, j, pixel2);
        }
    }
    return image;
}

int abs(int a)
{
  if (a < 0) {
    return -a;
  } else {
    return a;
  }
}


// Edge detection using Sobel filter
SDL_Surface *sobel_edge_detection(SDL_Surface *image){
    int kernel_x[3][3] = {{-1, 0, 1},
                      {-2, 0, 2},
                      {-1, 0, 1}};
    int kernel_y[3][3] = {{-1, -2, -1},
                        {0, 0, 0},
                        {1, 2, 1}};

    SDL_Surface *result = SDL_CreateRGBSurface(0, image->w, image->h, 32, 0, 0, 
    0, 0);
    for (int y = 0; y < image->h; y++) {
    for (int x = 0; x < image->w; x++) {
        if (x == 0 || x == image->w - 1 || y == 0 || y == image->h - 1) 
            continue;
       
        int gx = 0;
        int gy = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
            gx += getpixel(image, x + i, y + j) * kernel_x[i + 1][j + 1];
            gy += getpixel(image, x + i, y + j) * kernel_y[i + 1][j + 1];
            }
        }

        int g = sqrt(gx * gx + gy * gy);
        int theta = atan2(gy, gx);

        if (g < 128) continue;
        if (abs(theta) < 3.14 / 4 || abs(theta) > 3 * 3.14 / 4) {
            putpixel(result, x, y, 0);
        } else {
            putpixel(result, x, y, 255);
        }
        }
    }

    return result;
}



// Histogram of the image (for a given area)
int *histogram(SDL_Surface *image, int x1, int x2, int y1, int y2)
{
    int *histogram = malloc(256 * sizeof(int));
    for (int i = 0; i < 256; i++)
    {
        histogram[i] = 0;
    }
    for (int i = x1; i < x2; i++)
    {
        for (int j = y1; j < y2; j++)
        {
            Uint8 r, g, b;
            Uint32 pixel = getpixel(image, i, j);
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            histogram[r]++;
        }
    }
    return histogram;
}

// Threshold value for the image 
int threshold_value(int *histogram, int surface)
{
    int sum = 0;
    for (int i = 0; i < 256; i++)
    {
        sum += i * histogram[i];
    }
    float sumB = 0;
    int wB = 0;
    int wF = 0;
    float varMax = 0;
    int threshold = 0;
    for (int i = 0; i < 256; i++)
    {
        wB += histogram[i];
        if (wB == 0) continue;
        wF = surface - wB;
        if (wF == 0) break;
        sumB += (float)(i * histogram[i]);
        float mB = sumB / wB;
        float mF = (sum - sumB) / wF;
        float varBetween = (float)wB * (float)wF * (mB - mF) * (mB - mF);
        if (varBetween > varMax)
        {
            varMax = varBetween;
            threshold = i;
        }
    }
    return threshold;
}

// Image binarization using Otsu's method
SDL_Surface *otsu_threshold(SDL_Surface *image)
{
    int *hist = histogram(image, 0, image->w, 0, image->h);
    int threshold = threshold_value(hist, image->w * image->h);
    for (int i = 0; i < image->w; i++)
    {
        for (int j = 0; j < image->h; j++)
        {
            Uint8 r, g, b;
            Uint32 pixel = getpixel(image, i, j);
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            if (r < threshold)
            {
                Uint32 pixel2 = SDL_MapRGB(image->format, 0, 0, 0);
                putpixel(image, i, j, pixel2);
            }
            else
            {
                Uint32 pixel2 = SDL_MapRGB(image->format, 255, 255, 255);
                putpixel(image, i, j, pixel2);
            }
        }
    }
    return image;
}


/*
// Old version of the threshold function
SDL_Surface *threshold(SDL_Surface* image, int t)
{
    int width;
    int height;
    width = image->w;
    height = image->h;

	int surface = width * height;
    int *histogram = malloc(surface * sizeof(int));


	for (int i = 0; i < width;i++)
	{
		unsigned long sum = 0;
		for (int j = 0; j < height;j++)
		{
			Uint32 pixel = getpixel(image, i, j);
			Uint8 moy;
			SDL_GetRGB(pixel, image->format, &moy, &moy, &moy);
			sum += moy;
			if (i == 0)
			{
				histogram[j * width + i] = sum;
			}
			else
			{
				histogram[j * width + i] = histogram[(j) * width +i-1] + sum;
			}
		}
	}
	for (int k = 0; k < width;k++)
	{
		for (int l = 0; l < height; l++)
		{
			int x1 = k - t;
			int x2 = k + t;
			int y1 = l - t;
			int y2 = l + t;
            
			if(x1 <= 0) x1 = 1;
			if(x2 >= width) x2 = width - 1;
			if (y1 <= 0) y1 = 1;
			if (y2 >= height) y2 = height - 1;

			unsigned long count = (x2 - x1) * (y2 - y1);
			unsigned long sum1 = histogram[y2 * width + x2] - 
            histogram[(y1-1) * width + x2] - histogram[(y2) * width + x1-1] 
            + histogram[(y1 - 1) * width + x1-1];
			Uint8 moy2;
			SDL_GetRGB(getpixel(image, k, l), image->format, &moy2, &moy2, &moy2);
			if(((unsigned long)(moy2 * count)) > (double)(sum1 * (100 - t)/100)) 
			{
				putpixel(image, k, l, SDL_MapRGB(image->format,0, 0, 0));
			}
			else
			{
				putpixel(image,k,l, SDL_MapRGB(image->format,255,255,255));
			}
		}
	}
	free(histogram);
    return image;
}



// Intervert the color of the image
SDL_Surface *reverse(SDL_Surface* image, SDL_Surface* image2, int height, int width)
{
    for (int i = 0; i < width;i++)
    {
        for (int j = 0; j < height;j++)
        {
            Uint32 pixel = getpixel(image, i, j);
            Uint8 r;
            Uint8 g;
            Uint8 b;
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            if (r == 0)
            {
                Uint32 pixel2 = SDL_MapRGB(image->format,255,255,255);
                putpixel(image2, i, j, pixel2);
            }
            else
            {
                Uint32 pixel2 = SDL_MapRGB(image->format,0,0,0);
                putpixel(image2,i,j, pixel2);
            }
        }
    }
    return image2;
}

*/


void number(SDL_Surface* grid, SDL_Surface num, int w, int h, int x, int y)
{
    for (int i = 0; i < w; i++)
    {
        for (int j = 0; j < h; j++)
        {
            Uint32 pixel = getpixel(&num, i, j);
            if (pixel != SDL_MapRGB(num.format, 255, 255, 255))
                putpixel(grid, x + i, y + j, pixel);
        }
    }
}

// Draw the resolved grid 
SDL_Surface* draw_grid(char* filename, SDL_Surface* grid){
    SDL_Surface* img1;
    SDL_Surface* img2;
    SDL_Surface* img3;
    SDL_Surface* img4;
    SDL_Surface* img5;
    SDL_Surface* img6;
    SDL_Surface* img7;
    SDL_Surface* img8;
    SDL_Surface* img9;

    img1 = IMG_Load("images/1.jpg");
    img2 = IMG_Load("images/2.jpg");
    img3 = IMG_Load("images/3.jpg");
    img4 = IMG_Load("images/4.jpg");
    img5 = IMG_Load("images/5.jpg");
    img6 = IMG_Load("images/6.jpg");
    img7 = IMG_Load("images/7.jpg");
    img8 = IMG_Load("images/8.jpg");
    img9 = IMG_Load("images/9.jpg");

    int width = grid->w;
    int height = grid->h;
    int w = width / 9;
    int h = height / 9;

    int ch;
    int gridd[81];

    FILE *fp;
    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier");
        exit(1);
    }

    int i = 0;
    while((ch=fgetc(fp))!=EOF){
        if(ch=='1' || ch=='2' || ch=='3' || ch=='4' || ch=='5' || ch=='6'
				|| ch == '7' || ch == '8' || ch=='9')
		{
			gridd[i] = ch-48;
			i+=1;
		}
    }
    fclose(fp);
    
    for (int i = 0; i < 9; i++)
    {
        for (int j = 0; j < 9; j++)
        {
            if (gridd[i * 9 + j] == 1)
            {
                number(grid, *img1, w, h, j * w, i * h);
            }
            else if (gridd[i * 9 + j] == 2)
            {
                number(grid, *img2, w, h, j * w, i * h);
            }
            else if (gridd[i * 9 + j] == 3)
            {
                number(grid, *img3, w, h, j * w, i * h);
            }
            else if (gridd[i * 9 + j] == 4)
            {
                number(grid, *img4, w, h, j * w, i * h);
            }
            else if (gridd[i * 9 + j] == 5)
            {
                number(grid, *img5, w, h, j * w, i * h);
            }
            else if (gridd[i * 9 + j] == 6)
            {
                number(grid, *img6, w, h, j * w, i * h);
            }
            else if (gridd[i * 9 + j] == 7)
            {
                number(grid, *img7, w, h, j * w, i * h);
            }
            else if (gridd[i * 9 + j] == 8)
            {
                number(grid, *img8, w, h, j * w, i * h);
            }
            else if (gridd[i * 9 + j] == 9)
            {
                number(grid, *img9, w, h, j * w, i * h);
            }
        }
    }

    return grid;

}

// Converti une the image to a matrix
int** image_to_matrice(SDL_Surface* image)
{
    int width = image->w;
    int height = image->h;
    int** matrice = malloc(height * sizeof(int*));
    for (int i = 0; i < height; i++)
    {
        matrice[i] = malloc(width * sizeof(int));
    }
    for (int i = 0; i < width; i++)
    {
        for (int j = 0; j < height; j++)
        {
            Uint32 pixel = getpixel(image, i, j);
            Uint8 r;
            Uint8 g;
            Uint8 b;
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            if (r == 0)
            {
                matrice[j][i] = 1;
            }
            else
            {
                matrice[j][i] = 0;
            }
        }
    }
    return matrice;
}

// Resize the matrix to 28x28
int** resize_matrice(int** matrice, int width, int height)
{
    int** new_matrice = malloc(28 * sizeof(int*));
    for (int i = 0; i < 28; i++)
    {
        new_matrice[i] = malloc(28 * sizeof(int));
    }
    float ratio_width = (float)width / 28;
    float ratio_height = (float)height / 28;
    for (int i = 0; i < 28; i++)
    {
        for (int j = 0; j < 28; j++)
        {
            int x = (int)(ratio_width * i);
            int y = (int)(ratio_height * j);
            new_matrice[i][j] = matrice[x][y];
        }
    }
    return new_matrice;
}

// Write the matrix in a file
void write_matrice(int** matrice, char* filename)
{
    FILE* file = fopen(filename, "w+");
    for (int i = 0; i < 28; i++)
    {
        for (int j = 0; j < 28; j++)
        {
            fprintf(file, "%d", matrice[i][j]);
        }
    }
    fclose(file);
}

// Save the image in a file
void save(SDL_Surface *image, char *path)
{
    SDL_SaveBMP(image, path);
}

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        printf("Usage: %s image.bmp", argv[0]);
        return -1;
    }
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Surface *image = IMG_Load(argv[1]);
    SDL_Surface *grayscale_image = grayscale(image);
    save(grayscale_image, "images/grayscale.png");
    SDL_Surface *noise_canceled_image = noise_canceled(grayscale_image);       
    save(noise_canceled_image, "images/noise_canceled.png");


/*
    SDL_Surface *gaussian = gaussian_filter(noise_canceled_image);
    save(gaussian, "images/gaussian.png");

    SDL_Surface *sobeled = sobel_edge_detection(gaussian);
    save(sobeled, "images/sobel.png");
*/


    SDL_Surface *threshold_image = otsu_threshold(noise_canceled_image);
    save(threshold_image, "images/threshold.png");

    SDL_Surface *grille = IMG_Load("images/grid.jpg");
    SDL_Surface *drawed = draw_grid("images/grid_00.result",grille);
    save(drawed, "images/drawed.jpg");






    SDL_FreeSurface(image);
    SDL_FreeSurface(grayscale_image);
    SDL_FreeSurface(noise_canceled_image);
    /*
    SDL_FreeSurface(reverse_image);
    */


    SDL_Quit();
    return 0;
}
