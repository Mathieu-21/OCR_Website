// make a grayscale program with sdl2 that apply a grayscale filter to an image and save it

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include "grayscale.h"

Uint32 getpixel(SDL_Surface *surface, int x, int y) {
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch (bpp) {
    case 1:
        return *p;

    case 2:
        return *(Uint16 *)p;

    case 3:
        if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;

    case 4:
        return *(Uint32 *)p;

    default:
        return 0;
    }
}

void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel) {
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch (bpp) {
    case 1:
        *p = pixel;
        break;

    case 2:
        *(Uint16 *)p = pixel;
        break;

    case 3:
        if (SDL_BYTEORDER == SDL_BIG_ENDIAN) {
            p[0] = (pixel >> 16) & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = pixel & 0xff;
        } else {
            p[0] = pixel & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = (pixel >> 16) & 0xff;
        }
        break;

    case 4:
        *(Uint32 *)p = pixel;
        break;
    }
}

SDL_Surface *grayscale(SDL_Surface *image)
{
        for (int i = 0; i < image->w; i++)
    {
        for (int j = 0; j < image->h; j++)
        {
            Uint8 r, g, b;
            Uint32 pixel = getpixel(image, i, j);
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            Uint8 gray = (r + g + b) / 3;
            pixel = SDL_MapRGB(image->format, gray, gray, gray);
            putpixel(image, i, j, pixel);
        }
    }
    return image;
}

void save(SDL_Surface *image, char *path)
{
    SDL_SaveBMP(image, path);
}

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        printf("Usage: %s image.bmp", argv[0]);
        return -1;
    }
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Surface *image = IMG_Load(argv[1]);
    SDL_Surface *grayscale_image = grayscale(image);
    save(grayscale_image, "images/grayscale.png");
    SDL_FreeSurface(image);
    SDL_FreeSurface(grayscale_image);
    SDL_Quit();
    return 0;
}
