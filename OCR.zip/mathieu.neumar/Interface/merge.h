//
// Created by enzo on 01/12/22.
//

#ifndef OCR_MERGE_H
#define OCR_MERGE_H

#include "preprocessing.h"

SDL_Surface *prepro(char *path);
SDL_Surface *preprof(SDL_Surface *image);
SDL_Surface *prepros(SDL_Surface *grayscale_image);
SDL_Surface *preprot(SDL_Surface *noise_canceled_image);
SDL_Surface *preprofo(SDL_Surface *threshold_image, SDL_Surface *image);
char *sudo(char data[]);

#endif //OCR_MERGE_H
