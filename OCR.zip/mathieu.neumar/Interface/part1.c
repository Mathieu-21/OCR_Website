

#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gtk/gtkx.h>
#include <math.h>
#include <ctype.h>
#include <err.h>
#include "merge.h"
#include "manual_rotation.h"
#include "load_image.h"
#include "detection.h"
#include "../Solver/sudoku.h"

// Make them global

GtkWidget	*window;
GtkWidget	*fixed1;
GtkWidget	*file1;
GtkWidget	*file2;
GtkWidget	*button;
GtkWidget	*button_left;
GtkWidget	*button_right;
GtkWidget	*button_continue;
GtkWidget	*frame1;
GtkWidget	*frame2;
GtkWidget	*frame3;
GtkWidget	*frame4;
GtkWidget	*image1;
GtkWidget	*image5;
GtkWidget	*image4;
GtkWidget	*image3;
GtkWidget	*image2;
GtkWidget   *label1;
GtkWidget   *label2;
GtkWidget   *frame_fix1;
GtkWidget   *frame_fix2;
GtkWidget   *frame_fix3;
GtkWidget   *frame_fix4;
GtkBuilder	*builder;
SDL_Surface* final;
char *File;
char *File_folder;
char *Saved;
char *result;
SDL_Surface* image1SDL;
char data[81] = {'5','3','.','.','7','.','.','.','.',
              '6','.','.','1','9','5','.','.','.',
              '.','9','8','.','.','.','.','6','.',
              '8','.','.','.','6','.','.','.','3',
              '4','.','.','8','.','3','.','.','1',
              '7','.','.','.','2','.','.','.','6',
              '.','6','.','.','.','.','2','8','.',
              '.','.','.','4','1','9','.','.','5',
              '.','.','.','.','8','.','.','7','9'};


GtkListStore	*liststore1;
GtkAdjustment	*adjustment2;


int main(int argc, char *argv[]) {

    gtk_init(&argc, &argv); // init Gtk


    builder = gtk_builder_new_from_file ("part1.glade");

    window = GTK_WIDGET(gtk_builder_get_object(builder, "window"));

    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    gtk_builder_connect_signals(builder, NULL);

    fixed1 = GTK_WIDGET(gtk_builder_get_object(builder, "fixed1"));
    file1 = GTK_WIDGET(gtk_builder_get_object(builder, "file1"));
    file1 = GTK_WIDGET(gtk_builder_get_object(builder, "file2"));
    frame1 = GTK_WIDGET(gtk_builder_get_object(builder, "frame1"));
    frame2 = GTK_WIDGET(gtk_builder_get_object(builder, "frame2"));
    frame3 = GTK_WIDGET(gtk_builder_get_object(builder, "frame3"));
    frame4 = GTK_WIDGET(gtk_builder_get_object(builder, "frame4"));
    label1 = GTK_WIDGET(gtk_builder_get_object(builder, "label1"));
    label2 = GTK_WIDGET(gtk_builder_get_object(builder, "label2"));
    button = GTK_WIDGET(gtk_builder_get_object(builder, "button"));
    button_left = GTK_WIDGET(gtk_builder_get_object(builder, "button_left"));
    button_right = GTK_WIDGET(gtk_builder_get_object(builder, "button_right"));
    button_continue = GTK_WIDGET(gtk_builder_get_object(builder, "button_continue"));
    frame_fix1 = GTK_WIDGET(gtk_builder_get_object(builder, "frame_fix1"));
    frame_fix2 = GTK_WIDGET(gtk_builder_get_object(builder, "frame_fix2"));
    frame_fix3 = GTK_WIDGET(gtk_builder_get_object(builder, "frame_fix3"));
    frame_fix4 = GTK_WIDGET(gtk_builder_get_object(builder, "frame_fix4"));

    liststore1 = GTK_LIST_STORE(gtk_builder_get_object(builder, "liststore1"));
    adjustment2 = GTK_ADJUSTMENT(gtk_builder_get_object(builder, "adjustment2"));



    GdkColor color; // default background color
    color.red = 0xcccc;
    color.green = 0xcccc;
    color.blue = 0xd900;
    gtk_widget_modify_bg(GTK_WIDGET(window), GTK_STATE_NORMAL, &color);

    color.red = 0xaaaa;
    color.green = 0xaaaa;
    color.blue = 0xeeee;
    gtk_widget_modify_bg(frame1, GTK_STATE_NORMAL, &color);

    color.red = 0xaaaa;
    color.green = 0xeeee;
    color.blue = 0xaaaa;
    gtk_widget_modify_bg(frame2, GTK_STATE_NORMAL, &color);

    color.red = 0xeeee;
    color.green = 0xaaaa;
    color.blue = 0xaaaa;
    gtk_widget_modify_bg(frame3, GTK_STATE_NORMAL, &color);

    color.red = 0xeeee;
    color.green = 0xeeee;
    color.blue = 0xaaaa;

    gtk_widget_modify_bg(frame4, GTK_STATE_NORMAL, &color);

    gtk_widget_show(window);

    image1 = NULL;

    gtk_main();
    SDL_Quit();
    return EXIT_SUCCESS;
}


void	on_file1_file_set(GtkFileChooserButton *f) {
    File = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER(f));
    File_folder = gtk_file_chooser_get_current_folder (GTK_FILE_CHOOSER(f));

    if (image1)  gtk_container_remove (GTK_CONTAINER (frame_fix1), image1);
    if (image2)  gtk_container_remove (GTK_CONTAINER (frame_fix2), image2);
    if (image3)  gtk_container_remove (GTK_CONTAINER (frame_fix3), image3);
    if (image4)  gtk_container_remove (GTK_CONTAINER (frame_fix4), image4);
    if (image5)  gtk_container_remove (GTK_CONTAINER (frame_fix2), image5);
    // remove old slide

//	---------------------------------------------------------------
//	get the pixbuf
//	---------------------------------------------------------------
    GdkPixbuf *pix = gdk_pixbuf_new_from_file_at_scale(File,400,281,TRUE,NULL);

//	---------------------------------------------------------------
//	get the SDL
//	---------------------------------------------------------------
    image1 = gtk_image_new_from_pixbuf(pix);
    SDL_Init(SDL_INIT_VIDEO);
    image1SDL = IMG_Load(File);

//	---------------------------------------------------------------
//	convert pixbuf to image
//	---------------------------------------------------------------



    gtk_container_add (GTK_CONTAINER (frame_fix1), image1);
    gtk_widget_show(image1);


}

void	on_file2_folder_changed(GtkFileChooserButton *f) {
    Saved = gtk_file_chooser_get_current_folder (GTK_FILE_CHOOSER(f));
}

void	on_button_clicked() {
    if(Saved == NULL) return;
    char *sudo = "/sudoku";
    char *path = strcat(Saved, sudo);
    save(final,path);
}
void	on_button_left_clicked() {
    if(image1SDL == NULL) return;
    image1SDL = SDL_RotationCentralN(image1SDL, 45);
    if (image1)
    {
        gtk_container_remove (GTK_CONTAINER (frame_fix1), image1);
        image1 = gtk_image_new_from_sdl_surface(image1SDL, 250, 250);
        gtk_container_add (GTK_CONTAINER (frame_fix1), image1);
        gtk_widget_show(image1);
    }

}
void	on_button_right_clicked() {
    if(image1SDL == NULL) return;
    SDL_Surface *test = SDL_RotationCentralN(image1SDL, -45);
    //image1SDL =
    if (image1)
    {
        gtk_container_remove (GTK_CONTAINER (frame_fix1), image1);
        image1 = gtk_image_new_from_sdl_surface(test,250,250);
        gtk_container_add (GTK_CONTAINER (frame_fix1), image1);
        gtk_widget_show(image1);
    }
}
void	on_button_continue_clicked() {
    // preprocessing
    if(File == NULL) return;
    SDL_Surface *image = prepro(File);

    SDL_Surface *grayscale_image = preprof(image);
    image2 = gtk_image_new_from_sdl_surface (grayscale_image, 250, 250);

    SDL_Surface *noise_canceled_image = prepros (grayscale_image);
    image3 = gtk_image_new_from_sdl_surface (noise_canceled_image, 250, 250);

    SDL_Surface *threshold_image = preprot(noise_canceled_image);
    image4 = gtk_image_new_from_sdl_surface (threshold_image, 250, 250);

    SDL_Surface *reverse_image = preprofo(threshold_image, image);

    image5 = gtk_image_new_from_sdl_surface (reverse_image, 250, 250);



    gtk_container_add (GTK_CONTAINER (frame_fix2), image2);
    gtk_widget_show(image2);
    gtk_fixed_move (GTK_FIXED(frame_fix2),image2,0,10);
    gtk_container_add (GTK_CONTAINER (frame_fix2), image3);
    gtk_widget_show(image3);
    gtk_fixed_move (GTK_FIXED(frame_fix2),image3,260,10);
    gtk_container_add (GTK_CONTAINER (frame_fix2), image4);
    gtk_widget_show(image4);
    gtk_fixed_move (GTK_FIXED(frame_fix2),image4,520,10);
    gtk_container_add (GTK_CONTAINER (frame_fix2), image5);
    gtk_widget_show(image5);
    gtk_fixed_move (GTK_FIXED(frame_fix2),image5,780,10);
    char * t = strcat(File_folder,"image_revers.jpeg");
    save(reverse_image,t);
    SDL_FreeSurface(image);

}
void	on_button_continue2_clicked() {

    // line detection +ia
    char * t = strcat(File_folder,"image_revers.jpeg");
    SDL_Surface *surf = IMG_Load(t);
    SDL_Surface *reverse_image = SDL_ConvertSurfaceFormat(surf, SDL_PIXELFORMAT_RGB888, 0);
    SDL_FreeSurface(surf);

    int h = reverse_image->h;
    int w = reverse_image->w;
    int diagonale = (int)(sqrt((double)(w * w + h * h)));
    // get pixels
    Uint32 *pixels = reverse_image->pixels;
    // accumulator
    int *acc = calloc(360 * diagonale, sizeof(int));
    Accumulator_Create(reverse_image, acc, diagonale, w, h, pixels);

    // Accumulator_Browse(surface,diagonale,acc);
    int height_angle[10];
    int width_angle[10];
    int height_r[10];
    int width_r[10];
    size_t inter[100][2];
    Find_line(reverse_image, acc, diagonale, width_r, width_angle, height_r,
              height_angle);
    Find_inter( width_r, width_angle, height_r,
                height_angle, inter);

    Cut_case(reverse_image, inter, frame_fix3,result, File_folder);

    only_grille(reverse_image,inter);
    SDL_Window *window2 = SDL_CreateWindow(
            "final", 0, 0, 600, 400, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);

    if (window2 == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());
    SDL_SetWindowSize(window2, w, h);
    SDL_Renderer *renderer
            = SDL_CreateRenderer(window2, -1, SDL_RENDERER_ACCELERATED);

    if (renderer == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());

    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, reverse_image);
    if (texture == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());


    SDL_FreeSurface(reverse_image);
    event_loop(renderer, texture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window2);
    SDL_DestroyTexture(texture);



}

void	on_button_continue3_clicked() {

    SDL_Surface *image = prepro(File);
    solve(data);
    final = draw_grid(data,image);
    GtkWidget *fin = gtk_image_new_from_sdl_surface (final, 250, 250);
    gtk_container_add (GTK_CONTAINER (frame_fix4), fin);
    gtk_widget_show(fin);
    SDL_FreeSurface(image);

}