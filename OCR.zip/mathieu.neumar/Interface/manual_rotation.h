//
// Created by enzo on 10/12/22.
//

#ifndef INTERFACE_MANUAL_ROTATION_H
#define INTERFACE_MANUAL_ROTATION_H

Uint32 SDL_LirePixel(SDL_Surface* surface, int x, int y);
void SDL_EcrirePixel(SDL_Surface* surface, int x, int y, Uint32 pixel);
SDL_Surface* SDL_RotationCentralN(SDL_Surface* origine, float angle);

#endif //INTERFACE_MANUAL_ROTATION_H
