//
// Created by enzo on 01/12/22.
//

#ifndef OCR_PREPROCESSING_H
#define OCR_PREPROCESSING_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>

Uint32 getpixel(SDL_Surface *surface, int x, int y);
void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel);
SDL_Surface *grayscale(SDL_Surface *image);
Uint32 median_pixel(SDL_Surface *image, int x, int y);
SDL_Surface* noise_canceled(SDL_Surface *image);
SDL_Surface *threshold(SDL_Surface* image, int t);
SDL_Surface *reverse(SDL_Surface* image, SDL_Surface* image2, int height, int width);
void save(SDL_Surface *image, char *path);
void number(SDL_Surface* grid, SDL_Surface num, int w, int h, int x, int y);
SDL_Surface* draw_grid(char* data, SDL_Surface* grid);

#endif //OCR_PREPROCESSING_H
