
#ifndef OCR_DETECTION_H
#define OCR_DETECTION_H
#include <gtk/gtk.h>
#include <gtk/gtkx.h>

SDL_Surface *load_image2(const char *path);

GtkWidget * gtk_image_new_from_sdl_surface (SDL_Surface *surface, int x, int y);
void event_loop(SDL_Renderer *renderer, SDL_Texture *t);
void draw(SDL_Renderer *renderer, SDL_Texture *texture);
void Accumulator_Create(SDL_Surface *surface, int *acc, int diagonale, int w,
                        int h, Uint32 *pixels);
void Accumulator_pixels_add(int diagonale, int y, int *acc, int x);
void Accumulator_Browse(SDL_Surface *surface, int diagonale,
                        int *acc) ;
void Accumulator_pixels_red(SDL_Surface *surface, int rayon, int angle);
void Accumulator_pixels_blue(SDL_Surface *surface, int rayon, int angle);
void Find_line(SDL_Surface *surface, int *acc, int diagonale, int width_r[],
               int width_angle[], int height_r[], int height_angle[]);
void Find_inter(int height_r[],
                int height_angle[], int width_r[], int width_angle[],
                size_t inter[][2]);

void colored(SDL_Surface *surface, int x, int y);
SDL_Surface *nearest_neighbor(SDL_Surface *image);
void Cut_case(SDL_Surface *surface, size_t inter[][2], GtkWidget *frame_fix2, char* sudo, char* folder);
SDL_Surface *new_surface(SDL_Surface *surface, size_t x, size_t y, size_t x1,
                         size_t y1);
void only_grille(SDL_Surface *surface,size_t inter[][2]);
int main(int argc, char **argv) ;

#endif //OCR_DETECTION_H