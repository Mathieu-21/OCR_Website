#include "stdio.h"
#include "math.h"
#include "SDL.h"
#include "SDL_image.h"
#include <err.h>
#include "load_image.h"

SDL_Surface* load_image2(const char* path)
{
        SDL_Surface* surface = IMG_Load(path);
        if (surface == NULL)
        {
                errx(1,"Loading doesn't work: %s", IMG_GetError());
        }
        SDL_Surface* surfacecv = SDL_ConvertSurfaceFormat(surface,SDL_PIXELFORMAT_RGB888,0);
        if (surfacecv == NULL)
        {
                errx(1,"Convert doesn't work: %s", SDL_GetError());
        }
        SDL_FreeSurface(surface);
        return surfacecv;

}

