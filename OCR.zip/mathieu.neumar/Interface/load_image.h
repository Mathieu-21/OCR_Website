#include <stdlib.h>
#include <stdio.h>
#include <math.h>

SDL_Surface* load_image2(const char* path);

