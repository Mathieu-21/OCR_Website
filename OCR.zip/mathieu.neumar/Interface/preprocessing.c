// make a grayscale program with sdl2 that apply a grayscale filter to an image and save it

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>



Uint32 getpixel(SDL_Surface *surface, int x, int y) {
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch (bpp) {
    case 1:
        return *p;

    case 2:
        return *(Uint16 *)p;

    case 3:
        if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;

    case 4:
        return *(Uint32 *)p;

    default:
        return 0;
    }
}

void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel) {
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch (bpp) {
    case 1:
        *p = pixel;
        break;

    case 2:
        *(Uint16 *)p = pixel;
        break;

    case 3:
        if (SDL_BYTEORDER == SDL_BIG_ENDIAN) {
            p[0] = (pixel >> 16) & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = pixel & 0xff;
        } else {
            p[0] = pixel & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = (pixel >> 16) & 0xff;
        }
        break;

    case 4:
        *(Uint32 *)p = pixel;
        break;
    }
}

SDL_Surface *grayscale(SDL_Surface *image)
{
        for (int i = 0; i < image->w; i++)
    {
        for (int j = 0; j < image->h; j++)
        {
            Uint8 r, g, b;
            Uint32 pixel = getpixel(image, i, j);
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            Uint8 gray = r*0.2126 + g*0.7152 + b*0.0722;
            pixel = SDL_MapRGB(image->format, gray, gray, gray);
            putpixel(image, i, j, pixel);
        }
    }
    return image;
}

// Noise Suppression Part
Uint32 median_pixel(SDL_Surface *image, int x, int y)
{
        int iArr = 0;
        Uint32 grayscaleArr[9];
        for (int i = -1; i < 2; i++)
        {
                for (int j = -1; j < 2; j++)
                {
                        grayscaleArr[iArr] = getpixel(image, x+i, y+j);
                        iArr++;
                }
        }

        for (int i = 0; i < 8; i++)
        {
                Uint32 min = i;
                for (int j = i+1; j < 9; j++) if (grayscaleArr[j] < grayscaleArr[min]) min = j;
                Uint32 tmp = grayscaleArr[i];
                grayscaleArr[i] = grayscaleArr[min];
                grayscaleArr[min] = tmp;
        }

        return grayscaleArr[4];
}

SDL_Surface* noise_canceled(SDL_Surface *image)
{
	int w;
	int h;
	w = image -> w;
	h = image -> h;
	for (int i = 1; i < w-1; i++)
	{
		for (int j = 1; j < h-1; j++) putpixel(image, i, j, median_pixel(image, i, j));
	}
	return image;
}

SDL_Surface *threshold(SDL_Surface* image, int t)
{
    int width;
    int height;
    width = image->w;
    height = image->h;

	int surface = width * height;
    int *histogram = malloc(surface * sizeof(int));


	for (int i = 0; i < width;i++)
	{
		unsigned long sum = 0;
		for (int j = 0; j < height;j++)
		{
			Uint32 pixel = getpixel(image, i, j);
			Uint8 moy;
			SDL_GetRGB(pixel, image->format, &moy, &moy, &moy);
			sum += moy;
			if (i == 0)
			{
				histogram[j * width + i] = sum;
			}
			else
			{
				histogram[j * width + i] = histogram[(j) * width +i-1] + sum;
			}
		}
	}
	for (int k = 0; k < width;k++)
	{
		for (int l = 0; l < height; l++)
		{
			int x1 = k - t;
			int x2 = k + t;
			int y1 = l - t;
			int y2 = l + t;
            
			if(x1 <= 0) x1 = 1;
			if(x2 >= width) x2 = width - 1;
			if (y1 <= 0) y1 = 1;
			if (y2 >= height) y2 = height - 1;

			unsigned long count = (x2 - x1) * (y2 - y1);
			unsigned long sum1 = histogram[y2 * width + x2] - histogram[(y1-1) * width + x2] - histogram[(y2) * width + x1-1] + histogram[(y1 - 1) * width + x1-1];
			Uint8 moy2;
			SDL_GetRGB(getpixel(image, k, l), image->format, &moy2, &moy2, &moy2);
			if(((unsigned long)(moy2 * count)) > (double)(sum1 * (100 - t)/100)) 
			{
				putpixel(image, k, l, SDL_MapRGB(image->format,0, 0, 0));
			}
			else
			{
				putpixel(image,k,l, SDL_MapRGB(image->format,255,255,255));
			}
		}
	}
	free(histogram);
    return image;
}


SDL_Surface *reverse(SDL_Surface* image, SDL_Surface* image2, int height, int width)
{
    for (int i = 0; i < width;i++)
    {
        for (int j = 0; j < height;j++)
        {
            Uint32 pixel = getpixel(image, i, j);
            Uint8 r;
            Uint8 g;
            Uint8 b;
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            if (r == 0)
            {
                Uint32 pixel2 = SDL_MapRGB(image->format,255,255,255);
                putpixel(image2, i, j, pixel2);
            }
            else
            {
                Uint32 pixel2 = SDL_MapRGB(image->format,0,0,0);
                putpixel(image2,i,j, pixel2);
            }
        }
    }
    return image2;
}

/*
SDL_Surface *adaptative_gaussian_tresholding(SDL_Surface *image){
    int w = image->w;
    int h = image->h;
    SDL_Surface *new_image = SDL_CreateRGBSurface(0, w, h, 32, 0, 0, 0, 0);
    int i, j, k, l, m, n;
    int sum = 0;
    int mean = 0;
    int variance = 0;
    int standard_deviation = 0;
    Uint32 treshold = 0;
    Uint32 pixel = 0;

    for (i = 0; i < h; i++){
        for (j = 0; j < w; j++){
            for (k = 0; k < 3; k++){
                for (l = 0; l < 3; l++){
                    m = i + k - 1;
                    n = j + l - 1;
                    if (m < 0){
                        m = 0;
                    }
                    if (m > h - 1){
                        m = h - 1;
                    }
                    if (n < 0){
                        n = 0;
                    }
                    if (n > w - 1){
                        n = w - 1;
                    }
                    sum += getpixel(image, n, m);
                }
            }
            mean = sum / 9;
            sum = 0;
            for (k = 0; k < 3; k++){
                for (l = 0; l < 3; l++){
                    m = i + k - 1;
                    n = j + l - 1;
                    if (m < 0){
                        m = 0;
                    }
                    if (m > h - 1){
                        m = h - 1;
                    }
                    if (n < 0){
                        n = 0;
                    }
                    if (n > w - 1){
                        n = w - 1;
                    }
                    sum += (getpixel(image, n, m) - mean) * (getpixel(image, n, m) - mean);
                }
            }
            variance = sum / 9;
            sum = 0;
            standard_deviation = sqrt(variance);
            treshold = mean - standard_deviation;
            if (treshold < 0){
                treshold = 0;
            }
            if (getpixel(image, j, i) < treshold){
                pixel = 0;
            }
            else{
                pixel = 255;
            }
            putpixel(new_image, j, i, pixel);

        }

    }
    return new_image;
}


SDL_Surface *black_and_white(SDL_Surface *image){
    int w = image->w;
    int h = image->h;
    SDL_Surface *new_image = SDL_CreateRGBSurface(0, w, h, 32, 0, 0, 0, 0);
    int i, j;
    Uint32 pixel = 0;
    Uint8 r, g, b;

    for (i = 0; i < h; i++){
        for (j = 0; j < w; j++){
            pixel = getpixel(image, j, i);
            SDL_GetRGB(pixel, image->format, &r, &g, &b);
            if (b < 20){
                pixel = 0;
            }
            else{
                pixel = 255;
            }
            putpixel(new_image, j, i, pixel);
        }
    }
    return new_image;
}

*/

void number(SDL_Surface* grid, SDL_Surface num, int w, int h, int x, int y)
{
    for (int i = 0; i < w; i++)
    {
        for (int j = 0; j < h; j++)
        {
            Uint32 pixel = getpixel(&num, i, j);
            if (pixel != SDL_MapRGB(num.format, 255, 255, 255))
                putpixel(grid, x + i, y + j, pixel);
        }
    }
}

// Draw the resolved grid
SDL_Surface* draw_grid(char* data, SDL_Surface* grid){
    SDL_Surface* img1;
    SDL_Surface* img2;
    SDL_Surface* img3;
    SDL_Surface* img4;
    SDL_Surface* img5;
    SDL_Surface* img6;
    SDL_Surface* img7;
    SDL_Surface* img8;
    SDL_Surface* img9;

    img1 = IMG_Load("images/1.png");
    img2 = IMG_Load("images/2.png");
    img3 = IMG_Load("images/3.png");
    img4 = IMG_Load("images/4.png");
    img5 = IMG_Load("images/5.png");
    img6 = IMG_Load("images/6.png");
    img7 = IMG_Load("images/7.png");
    img8 = IMG_Load("images/8.png");
    img9 = IMG_Load("images/9.png");

    int width = grid->w;
    int height = grid->h;
    int w = width / 9;
    int h = height / 9;


    for (int i = 0; i < 9; i++)
    {
        for (int j = 0; j < 9; j++)
        {
            if (data[i * 9 + j] == '1')
            {
                number(grid, *img1, w, h, j * w, i * h);
            }
            else if (data[i * 9 + j] == '2')
            {
                number(grid, *img2, w, h, j * w, i * h);
            }
            else if (data[i * 9 + j] == '3')
            {
                number(grid, *img3, w, h, j * w, i * h);
            }
            else if (data[i * 9 + j] == '4')
            {
                number(grid, *img4, w, h, j * w, i * h);
            }
            else if (data[i * 9 + j] == '5')
            {
                number(grid, *img5, w, h, j * w, i * h);
            }
            else if (data[i * 9 + j] == '6')
            {
                number(grid, *img6, w, h, j * w, i * h);
            }
            else if (data[i * 9 + j] == '7')
            {
                number(grid, *img7, w, h, j * w, i * h);
            }
            else if (data[i * 9 + j] == '8')
            {
                number(grid, *img8, w, h, j * w, i * h);
            }
            else if (data[i * 9 + j] == '9')
            {
                number(grid, *img9, w, h, j * w, i * h);
            }
        }
    }

    return grid;

}


void save(SDL_Surface *image, char *path)
{
    SDL_SaveBMP(image, path);
}

