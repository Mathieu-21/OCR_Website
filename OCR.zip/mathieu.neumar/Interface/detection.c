#include <SDL2/SDL_image.h>
#include <err.h>
#include <math.h>
#include <stdio.h>
#include <sys/stat.h>
#include "detection.h"
#include <SDL2/SDL.h>


/**
SDL_Surface *load_image2(const char *path)
{
	// load the image , with the path of the image in parameter
	SDL_Surface *surf = IMG_Load(path);
	SDL_Surface *nf = SDL_ConvertSurfaceFormat(surf, SDL_PIXELFORMAT_RGB888, 0);
	SDL_FreeSurface(surf);
	return nf;
}
**/

GtkWidget * gtk_image_new_from_sdl_surface (SDL_Surface *surface, int x, int y)
{
    Uint32 src_format;
    Uint32 dst_format;

    GdkPixbuf *pixbuf;
    gboolean has_alpha;
    int rowstride;
    guchar *pixels;

    GtkWidget *image;

    // select format
    src_format = surface->format->format;
    has_alpha = SDL_ISPIXELFORMAT_ALPHA(src_format);
    if (has_alpha) {
        dst_format = SDL_PIXELFORMAT_RGBA32;
    }
    else {
        dst_format = SDL_PIXELFORMAT_RGB24;
    }

    // create pixbuf
    pixbuf = gdk_pixbuf_new (GDK_COLORSPACE_RGB, has_alpha, 8,
                             surface->w, surface->h);
    rowstride = gdk_pixbuf_get_rowstride (pixbuf);
    pixels = gdk_pixbuf_get_pixels (pixbuf);

    // copy pixels
    SDL_LockSurface(surface);
    SDL_ConvertPixels (surface->w, surface->h, src_format,
                       surface->pixels, surface->pitch,
                       dst_format, pixels, rowstride);
    SDL_UnlockSurface(surface);


    pixbuf = gdk_pixbuf_scale_simple(pixbuf,x,y,GDK_INTERP_BILINEAR);
    // create GtkImage from pixbuf
    image = gtk_image_new_from_pixbuf (pixbuf);

    // release our reference to the pixbuf
    g_object_unref (pixbuf);

    return image;
}

// Event loop that calls the relevant event handler.
//
// renderer: Renderer to draw on.
void draw(SDL_Renderer *renderer, SDL_Texture *texture) {

    if (SDL_RenderCopy(renderer, texture, NULL, NULL) != 0)
        errx(EXIT_FAILURE, "%s", SDL_GetError());
    SDL_RenderPresent(renderer);
}
void event_loop(SDL_Renderer *renderer, SDL_Texture *t) {
    SDL_Event event;
    while (1) {
        SDL_WaitEvent(&event);

        switch (event.type) {
            // If the "quit" button is pushed, ends the event loop.
            case SDL_QUIT: return;

                // If the window is resized, updates and redraws the diagonals.
            case SDL_WINDOWEVENT:
                if (event.window.event == SDL_WINDOWEVENT_RESIZED) {

                    draw(renderer, t);
                }
                break;
        }
    }
}

void Accumulator_pixels_add(int diagonale, int y, int *acc, int x) {
    for (int angle = 0; angle < 180; ++angle) {
        int rayon
                = (sin(M_PI / 180 * angle)) * y + (cos(M_PI / 180 * angle)) * x;
        int condition = rayon < diagonale && rayon > 0;

        if (condition) {

            acc[angle + 360 * rayon] = acc[angle + 360 * rayon] + 1;
        }
    }
}
void Accumulator_Create(SDL_Surface *surface, int *acc, int diagonale, int w,
                        int h, Uint32 *pixels) {
    for (int x = 0; x < w; x++) {

        for (int y = 0; y < h; y++) {

            SDL_PixelFormat *format = surface->format;
            Uint8 r, g, b;

            SDL_GetRGB(pixels[y * w + x], format, &r, &g, &b);

            Uint8 rgb = r + g + b;
            if (rgb == 0) { Accumulator_pixels_add(diagonale, y, acc, x);
            }
        }
    }
}

void Accumulator_pixels_red(SDL_Surface *surface, int rayon, int angle) {
    SDL_PixelFormat *format = surface->format;
    Uint32 red = SDL_MapRGB(format, 255, 0, 0);
    Uint32 *pixels = surface->pixels;
    for (int x = 0; x < surface->w; ++x) {
        for (int y = 0; y < surface->h; ++y) {
            int rayon2 = ((sin(M_PI / 180 * angle)) * y
                          + (cos(M_PI / 180 * angle)) * x);
            if (rayon2 == rayon) {
                int w = surface->w;
                pixels[y * w + x] = red;
            }
        }
    }
}
void Accumulator_Browse(SDL_Surface *surface, int diagonale,
                        int *acc) // calls drawline
{

    for (int angle = 0; angle < 180; ++angle) {
        for (int rayon = 0; rayon < diagonale; ++rayon) {
            if (acc[angle + 360 * rayon] > surface->h/3) {
                // create red pixels where lines are
                Accumulator_pixels_red(surface, rayon,
                                       angle);
            }
        }
    }
}

void Accumulator_pixels_blue(SDL_Surface *surface, int rayon, int angle) {
    SDL_PixelFormat *format = surface->format;
    Uint32 blue = SDL_MapRGB(format, 0, 255, 0);
    Uint32 *pixels = surface->pixels;
    for (int x = 0; x < surface->w; ++x) {
        for (int y = 0; y < surface->h; ++y) {
            int rayon2 = ((sin(M_PI / 180 * angle)) * y
                          + (cos(M_PI / 180 * angle)) * x);
            if (rayon2 == rayon) {
                int w = surface->w;
                pixels[y * w + x] = blue;
            }
        }
    }
}

void Find_line(SDL_Surface *surface, int *acc, int diagonale, int width_r[],
               int width_angle[], int height_r[], int height_angle[]) {
    // horizontal
    int y = 50;
    int i = 0;
    for (int x = 0; x < surface->w && i != 10; x++) {
        int ii = 0;
        for (int angle = 0; angle < 180 && ii == 0; ++angle) {
            int rayon
                    = (sin(M_PI / 180 * angle)) * y + (cos(M_PI / 180 * angle)) * x;
            int condition = rayon < diagonale && rayon > 0;
            if (condition && acc[angle + 360 * rayon] > surface->h/3+50) {
                ++ii;

                width_angle[i] = angle;
                width_r[i] = rayon;
                ++i;
                x += 100;
            }
        }
    }
    // vertical
    int x = 50;
    i = 0;
    for (int y = 15; y < surface->h && i != 11; y++) {
        int ii = 0;
        for (int angle = 0; angle < 180 && ii == 0; ++angle) {
            int rayon
                    = (sin(M_PI / 180 * angle)) * y + (cos(M_PI / 180 * angle)) * x;
            int condition = rayon < diagonale && rayon > 0;
            if (condition && acc[angle + 360 * rayon] > surface->h/3+50) {
                ++ii;
                height_angle[i] = angle;
                height_r[i] = rayon;
                ++i;
                y += 100;
            }
        }
    }
}
void Find_inter( int height_r[],
                 int height_angle[], int width_r[], int width_angle[],
                 size_t inter[][2]) {

    for (int i = 0; i < 10; i++) {
        for (int k = 0; k < 10; k++) {

            size_t wr = width_r[i];
            size_t hr = height_r[k];
            float ch = cos(height_angle[k] * M_PI / 180);
            float sh = sin(height_angle[k] * M_PI / 180);
            float sw = sin(width_angle[i] * M_PI / 180);
            float cw = cos(width_angle[i] * M_PI / 180);

            size_t x = (sw * hr - sh * wr) / (sw * ch - sh * cw);

            size_t y = (wr - x * cw) / sw;

            inter[i * 10 + k][0] = x;
            inter[i * 10 + k][1] = y;
        }
    }
}

void colored(SDL_Surface *surface, int x, int y) {
    SDL_PixelFormat *format = surface->format;
    Uint32 blue = SDL_MapRGB(format, 250,37,203);
    Uint32 *pixels = surface->pixels;
    for(int i = -5; i < 5; i++){
        for(int j = -5; j < 5; j++){
            pixels[(y + i) * surface->w + (x + j)] = blue;
        }
    }

}
SDL_Surface *new_surface(SDL_Surface *surface, size_t x, size_t y, size_t x1,
                         size_t y1) {
    SDL_Surface *new = SDL_CreateRGBSurface(0, x, y, 32, 0, 0, 0, 0);
    Uint32 *pixels = new->pixels;
    Uint32 *pix = surface->pixels;
    for (size_t i = 0; i < x; i++) {
        for (size_t k = 0; k < y; k++) {
            pixels[k * x + i] = pix[(y1 + k) * surface->w + (x1 + i)];
        }
    }
    return new;
}

SDL_Surface *nearest_neighbor(SDL_Surface *image)
{
    // Create a new surface with the desired dimensions (28x28 in this case)
    int w = 28;
    int h = 28;
    SDL_Surface *new_surface = SDL_CreateRGBSurface(0, w, h, image->format->BitsPerPixel, image->format->Rmask, image->format->Gmask, image->format->Bmask, image->format->Amask);
    Uint32 *pixels = new_surface->pixels;
    Uint32 *pixels0 = image->pixels;
    // Get the dimensions of the original image
    int w_original = image->w;
    int h_original = image->h;
    // Calculate the scaling factor for the x and y dimensions
    float x_scale = (float)w / (float)w_original;
    float y_scale = (float)h / (float)h_original;

    // For each pixel in the new image
    for (int x = 0; x < w; x++) {
        for (int y = 0; y < h; y++) {
            // Calculate the coordinates of the pixel in the original image
            int x_original = (int)((float)x / x_scale);
            int y_original = (int)((float)y / y_scale);

            // Get the value of the nearest pixel in the original image
            Uint32 pixel = pixels0[y_original * w_original + x_original];

            // Set the value of the new pixel
            pixels[y * w + x] = pixel;
        }
    }
    return new_surface;
}

void Cut_case(SDL_Surface *surface, size_t inter[][2], GtkWidget *frame_fix2, char* sudo, char* folder) {
    int j = 0;
    strcat(folder,"/case");
    printf("%s\n",folder);
    mkdir(folder, 0700);
    strcat(folder ,"/list_test");
    printf("%s\n",folder);
    mkdir(folder, 0700);
    for (size_t i = 0; i <= 80; i += 10) {
        for (size_t k = 0; k < 9; k++) {

            size_t x = inter[i + k + 11][0] - inter[i + k][0];
            size_t y = inter[i + k + 11][1] - inter[i + k][1];
            char name[70];
            sprintf(name, "%s/%i", folder,j);
            SDL_Surface *new
                    =new_surface(surface, 88, 88, inter[i + k][0]+x/2-40, inter[i + k][1]+y/2-48);
            SDL_Surface *new2=nearest_neighbor(new);

            SDL_SaveBMP(new2, name);
            // use neural network on the result and save it + print the result
                 //sudo[j] == résultat du réseau de neurone
            char name2[10];
            sprintf(name2, "%i", j);
            GtkWidget *img = gtk_image_new_from_sdl_surface (new2, 25, 25);
            GtkWidget *label = gtk_label_new_with_mnemonic (name2);
            gtk_container_add (GTK_CONTAINER (frame_fix2), img);
            gtk_container_add (GTK_CONTAINER (frame_fix2), label);
            gtk_widget_show(img);
            gtk_widget_show(label);
            gtk_fixed_move (GTK_FIXED(frame_fix2),img,20*(j%9)+(j%9)*25,20*(j/9)+(j/9)*25);
            gtk_fixed_move (GTK_FIXED(frame_fix2),label,20*(j%9)+(j%9)*25+12,20*(j/9)+(j/9)*25+25);

            j++;
        }
    }
}

void only_grille(SDL_Surface *surface,size_t inter[][2])
{
    char name[45];
    sprintf(name, "./gate/%s", "test.png" );
    SDL_Surface *new
            = new_surface(surface, inter[99][0] - inter[0][0], inter[99][1] - inter[0][1], inter[0][0], inter[0][1]);
    SDL_SaveBMP(new, name);
}

/*
int main(int argc, char **argv) {

	// Checks the number of arguments.
	if (argc != 2) errx(EXIT_FAILURE, "Usage: image-file");
	SDL_Surface *surface = load_image2(argv[1]);

	if (surface == NULL) { errx(EXIT_FAILURE, "%s", SDL_GetError()); }

	// Get size of image
	int h = surface->h;
	int w = surface->w;
	int diagonale = (int)(sqrt((double)(w * w + h * h)));
	// get pixels
	Uint32 *pixels = surface->pixels;
	// accumulator
	int *acc = calloc(360 * diagonale, sizeof(int));
	Accumulator_Create(surface, acc, diagonale, w, h, pixels);

	// Accumulator_Browse(surface,diagonale,acc);
	int height_angle[10];
	int width_angle[10];
	int height_r[10];
	int width_r[10];
	size_t inter[100][2];
	Find_line(surface, acc, diagonale, width_r, width_angle, height_r,
			  height_angle);
	Find_inter( width_r, width_angle, height_r,
			   height_angle, inter);

	Cut_case(surface, inter);

	only_grille(surface,inter);
	SDL_Window *window = SDL_CreateWindow(
		"final", 0, 0, 600, 400, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);

	if (window == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());
	SDL_SetWindowSize(window, w, h);
	SDL_Renderer *renderer
		= SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	if (renderer == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());

	SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
	if (texture == NULL) errx(EXIT_FAILURE, "%s", SDL_GetError());

	SDL_FreeSurface(surface);
	event_loop(renderer, texture);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_DestroyTexture(texture);
	SDL_Quit();

	//
	// - Initialize the SDL.
	// - Create a window.
	// - Create a renderer.
	// - Create a surface from the colored image.
	// - Resize the window according to the size of the image.
	// - Create a texture from the colored surface.
	// - Convert the surface into grayscale.
	// - Create a new texture from the grayscale surface.
	// - Free the surface.
	// - Dispatch the events.
	// - Destroy the objects.

	return EXIT_SUCCESS;
}
 */

