//
// Created by enzo on 01/12/22.
//


#include "preprocessing.h"

SDL_Surface *prepro(char *path)
{
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Surface *image = IMG_Load(path);
    return image;
}

SDL_Surface *preprof(SDL_Surface *image)
{
    SDL_Surface *grayscale_image = grayscale(image);
    return grayscale_image;
}

SDL_Surface *prepros(SDL_Surface *grayscale_image)
{
    SDL_Surface *noise_canceled_image = noise_canceled(grayscale_image);
    return noise_canceled_image;
}

SDL_Surface *preprot(SDL_Surface *noise_canceled_image)
{
    SDL_Surface *threshold_image = threshold(noise_canceled_image,40);
    return threshold_image;
}

SDL_Surface* preprofo(SDL_Surface *threshold_image, SDL_Surface *image)
{
    SDL_Surface *reverse_image = reverse(threshold_image, image, image->h, image->w);
    return reverse_image;
}



