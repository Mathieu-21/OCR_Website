//
// Created by enzoj on 9/14/2022.
//

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* reada(char *filename)
{
    FILE* file = fopen(filename, "r");
    char line;
    size_t i = 0;
    char sudoku[81];
    char* sudo = sudoku;

    while ((line = fgetc(file)) != EOF)
    {
        if(line != ' ' && line != '\n')
        {
            sudo[i] = line;
            i++;
        }
    }
    fclose(file);


    return sudo;
}

void writea(char data[],char *filename)
{
    // first add .result to filename
    size_t t = 0;
    for (size_t i = 0; filename[i]!= 0 ; ++i)
    {
        t++;
    }
    char * copy = NULL;
    copy = (char*) malloc((t+8) * sizeof(char) );
    char name[t+8];

    for (size_t a = 0; a <= t; ++a)
    {
        name[a] = filename[a];
    }
    char result[] = {'.','r','e','s','u','l','t',0};
    size_t y = 0;
    for (size_t i = t; i <= t+8; ++i)
    {
        name[i] = result[y];
        y++;
    }

    strcpy( copy, name );

    FILE * fPtr;
    /*
     * Open file in w (write) mode.*/
    fPtr = fopen(copy, "w");

    // Write data to file
    for (int i = 0; i < 9; ++i)
    {
        for (int j = 0; j < 9; ++j)
        {
            if (j==8 && i != 8)
            {
                fputc(data[i*9+j], fPtr);
                fputc('\n', fPtr);
            }
            else if( j ==2 || j == 5)
            {
                fputc(data[i*9+j], fPtr);
                fputc(' ', fPtr);
            }
            else
            {
                fputc(data[i*9+j], fPtr);
            }
        }
        if(i == 2 || i == 5)
        {
            fputc('\n', fPtr);
        }
    }

    fclose(fPtr);
    free(copy);
}

int find_empty(size_t* row_e, size_t* col_e, char sudo[])  // find an empty case
{
    for (size_t i = 0; i < 9; ++i)
    {
        for (size_t j = 0; j < 9; ++j)
        {
            if(sudo[i*9+j] == '.')
            {
                *row_e = i;
                *col_e = j;
                return 1;
            }
        }
    }
    return 0;
}

int valid(char sudo[], char number, size_t row, size_t col) // check if the sudoku is valid
{
    for (size_t i = 0; i < 9; ++i)
    {
        if(sudo[row*9+i] == number && i!= col)
        {
            return 0;
        }
    }

    for (size_t j = 0; j < 9; ++j)
    {
        if(sudo[j*9+col] == number && j!= row)
        {
            return 0;
        }
    }

    for (size_t i = (row/3)*3; i < row/3+3; ++i)
    {
        for (size_t j = (col/3)*3; j < col/3+3; ++j)
        {
            if(sudo[i*9+j] == number && i != row && j != col)
            {
                return 0;
            }
        }
    }

    return 1;
}


int solve(char sudo[])
{
    size_t row_empty;
    size_t col_empty;
    if (find_empty(&row_empty,&col_empty,sudo))
    {
        for (char i = '1'; i <= '9'; ++i)
        {
            if (valid(sudo,i,row_empty,col_empty))
            {
                sudo[row_empty*9+col_empty] = i;
                if (solve(sudo))
                {
                    return 1;
                }
                sudo[row_empty*9+col_empty] = '.';  // go back because the number does not work
            }
        }
    }
    else
    {
        return 1;
    }
    return 0;
}






