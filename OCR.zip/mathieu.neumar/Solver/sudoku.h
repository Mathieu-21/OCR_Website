//
// Created by enzoj on 9/21/2022.
//
#include <stddef.h>

#ifndef PARTITION_IS_PARTITION_H
#define PARTITION_IS_PARTITION_H

char* reada(char *filename);
void writea(char* sudoku, char *filename);
int find_empty(size_t* row_e, size_t* col_e, char sudo[]);
int valid(char sudo[], char number, size_t row, size_t col);
int solve(char sudo[]);

#endif
