//
// Created by enzoj on 9/14/2022.
//

#include "sudoku.h"



int main(int argc, char **argv)
{
    int result;
    char* sudoku;
    sudoku = reada(argv[1]);

    char data[81];
    for (int i = 0; i < 81; ++i)
    {
        data[i] = sudoku[i];
    }

    result = solve(data);

    writea(data, argv[1]);

    return result;
}

