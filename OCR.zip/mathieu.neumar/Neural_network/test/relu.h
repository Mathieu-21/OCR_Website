#ifndef RELU_H
#define RELU_H

double relu(double x);

#endif