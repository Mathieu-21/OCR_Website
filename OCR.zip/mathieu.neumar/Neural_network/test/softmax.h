#include <stddef.h>

#ifndef SOFTMAX_H
#define SOFTMAX_H

void softmax(double* input, size_t size);

#endif