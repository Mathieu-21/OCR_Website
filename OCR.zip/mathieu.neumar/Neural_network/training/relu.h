#ifndef RELU_H
#define RELU_H

double relu(double x);
double dRelu(double x);

#endif