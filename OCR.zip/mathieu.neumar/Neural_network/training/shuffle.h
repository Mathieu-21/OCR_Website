#ifndef SHUFFLE_H
#define SHUFFLE_H

void shuffle(int *array, size_t n);

#endif
