#ifndef INIT_RANDOM_H
#define INIT_RANDOM_H

double init_random();

#endif
